<?php
$dev_constants = [
    'PG_DB_HOST'        =>  'localhost',
    'PG_DB_PORT'        =>  '5432',
    'PG_DB_DATABASE'    =>  'icarepro',
    'PG_DB_USERNAME'    =>  'mudassir.manzoor',
    'PG_DB_PASSWORD'    =>  'ds1234',
];
?>