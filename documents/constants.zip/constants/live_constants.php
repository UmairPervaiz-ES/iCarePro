<?php
$live_constants = [
    'PG_DB_HOST'        =>  'localhost',
    'PG_DB_PORT'        =>  '5432',
    'PG_DB_DATABASE'    =>  'icarepro',
    'PG_DB_USERNAME'    =>  'muhammad.qasim',
    'PG_DB_PASSWORD'    =>  'ds1234',
    // 'MONGO_DSN'  => 'mongodb://localhost:27017',
    // 'MONGO_DB'   => 'liveness',
];
?>
